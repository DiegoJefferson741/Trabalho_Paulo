Gerenciar vendas de bilhete.
bilhetes de festa.
diferentes tipos de produtos
qualquer tipo de comida. salgadinhos e bebidas.

comprar o bilhete na entrada e dentro da festa comprar o que quiser consumir.


pessoas que estarao trabalhando na festa. 
gerenciar o pagamento d equem ta trabalhando na festa.

cada pessoa tera sua função. guixe, cozinha.
nao tera venda de mesas e nem camarote.
limite maximo de vendas d eingresso.
caso estoure o limite maximo, a venda de ingressos ira parar.

vendas em cartao e dinheiro.
sera anunciado na cidade, vendas antecipadas tanto em ponto quanto online.


Sistema adm page venda bilhete.

Sistema de vendas de bilhetes.
Versao web e appweb.
contabiliza a quantidade que foi vendida de bilhetes
contabiliza a quantidade faltante de bilhetes.
contabiliza como foi realizada a venda, cartao dinheiro.
contabiliza a quantidade que foi vendida no cartao ou no dinheiro.



----------------------------------

Sistema adm page admin funcionarios.
Operador do Sistema cadastra o funcionario e a função.
Operador cadastra o valor a ser recebido por cada funcionario.

-------------------------------------

Funcionarios:

Adm do sistema.: quem cadastra os funcionarios

vendedores/pontos de venda: funcionarios com acesso a pagina de vendas e todas a funções relacionadas.(quantidade vendida/faltante/modalidade de venda)

garçons: funcionarios que atendem as mesas.

seguranças: funcionarios que cuidam da segurança.

limpesza: funcionariops que cuidam da limpesa do ambiente e dependencias.

fornecedores: sao funcionarios que cuidam das entregas das comidas e bebidas, decoração e equipamentos.

musicos: funcionarios responsaveis pelo intreternuimento da festa.

vendedores internos: funcionarios responsaveis pelas vendas intena da festa. cada vendedor interno e responsavel por cadastrar cada venda por mesa e como sera realizado a cobraça de cada mesa.
---------------------------------------------

vendas durante a festa:
cada vendedor interno sera cadastrado e tera acesso a um pagina do sistema onde tera acesso a prços e valores do que esta sendo comercializado.
durante cada venda sera cadastrado a mesa atendida o valor pago e a forma de pagamento.



---------------------------------------------

ao final da festa cada vendedor interno tera um relatorio total de quanto foi vendido total de formas de pagamento e valor a receber.

ao final da festa cada administrador do sistema tera aesso aos valores totais e quanto tera que pagar para cada funcionario dentro de suas respectivas funções.

